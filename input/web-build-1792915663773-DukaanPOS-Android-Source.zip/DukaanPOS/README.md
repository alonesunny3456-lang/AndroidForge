# Dukaan POS — Android source project

A native Android starter project for a bilingual physical-shop POS. It uses SQLite for on-device persistence and Android's file picker for JSON backup/restore.

## Features
- English / Urdu interface toggle
- PKR formatting
- Product inventory, costs, selling prices and stock deduction on sale
- Customer register
- Cash / partial / full-credit sales
- Customer udhaar repayments
- Expense entries and summary reports
- Export database data to JSON and restore from JSON
- Offline-first; no account or internet required once installed

## Build an APK without owning a computer (GitHub Actions route)
This project includes `.github/workflows/build-apk.yml` to build a debug APK on GitHub's cloud runners.
1. On your phone, sign in to GitHub in a browser and create a new **public or private repository**.
2. Upload the contents of this project ZIP to the repository (extract the ZIP first if GitHub's upload page requires individual files; ensure `.github/workflows/build-apk.yml` is included).
3. Open the repository's **Actions** tab and select **Build Dukaan POS APK**. If prompted, enable workflows and tap **Run workflow**.
4. When the run finishes successfully, open that run and download the **DukaanPOS-debug-apk** artifact.
5. Extract the downloaded artifact ZIP on your phone, tap `app-debug.apk`, and follow Android's install prompts. Only install APKs you built or trust.

## Important
This is source code plus a cloud build workflow, not a precompiled APK. The first cloud build must succeed before an APK artifact appears. The app is local to one device; it does not sync automatically between phone and computer. Reports aggregate all records, not date-filtered daily closing. No barcode scanning, thermal printer integration, user login, or cloud sync yet. Backups contain business and customer records; keep them private. Restoring a backup replaces current records, so back up first.
