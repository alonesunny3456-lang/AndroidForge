package com.dukaan.pos;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import org.json.*;

public class DB extends SQLiteOpenHelper {
    public DB(Context c){super(c,"dukaan_pos.db",null,1);}
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT,cost REAL NOT NULL,price REAL NOT NULL,stock INTEGER NOT NULL)");
        d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT)");
        d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,product_name TEXT,customer_id INTEGER,customer_name TEXT,qty INTEGER,cost REAL,price REAL,discount REAL,total REAL,paid REAL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER,customer_name TEXT,amount REAL,note TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        d.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,amount REAL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        ContentValues c=new ContentValues();c.put("name","Walk-in Customer");c.put("phone","");d.insert("customers",null,c);
        ContentValues p=new ContentValues();p.put("name","Sample Item A");p.put("category","General");p.put("cost",500);p.put("price",750);p.put("stock",10);d.insert("products",null,p);
        p=new ContentValues();p.put("name","Sample Item B");p.put("category","General");p.put("cost",200);p.put("price",300);p.put("stock",20);d.insert("products",null,p);
    }
    public void onUpgrade(SQLiteDatabase d,int o,int n){}
    public JSONObject exportJson() throws Exception {
        JSONObject root=new JSONObject(); SQLiteDatabase d=getReadableDatabase();
        for(String table:new String[]{"products","customers","sales","payments","expenses"}){
            JSONArray arr=new JSONArray(); Cursor c=d.rawQuery("SELECT * FROM "+table,null);
            while(c.moveToNext()){JSONObject row=new JSONObject();for(int i=0;i<c.getColumnCount();i++){int type=c.getType(i);Object v=type==Cursor.FIELD_TYPE_NULL?JSONObject.NULL:type==Cursor.FIELD_TYPE_INTEGER?c.getLong(i):type==Cursor.FIELD_TYPE_FLOAT?c.getDouble(i):c.getString(i);row.put(c.getColumnName(i),v);}arr.put(row);}c.close();root.put(table,arr);
        } return root;
    }
    public void importJson(JSONObject root) throws Exception {
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{
            for(String table:new String[]{"products","customers","sales","payments","expenses"}){
                d.delete(table,null,null);JSONArray a=root.optJSONArray(table);if(a==null)continue;
                for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);ContentValues v=new ContentValues();java.util.Iterator<String> it=o.keys();while(it.hasNext()){String k=it.next();if(k.equals("id"))continue;Object x=o.get(k);if(x==JSONObject.NULL)v.putNull(k);else if(x instanceof Integer||x instanceof Long)v.put(k,((Number)x).longValue());else if(x instanceof Number)v.put(k,((Number)x).doubleValue());else v.put(k,String.valueOf(x));}d.insert(table,null,v);}
            } d.setTransactionSuccessful();
        }finally{d.endTransaction();}
    }
}
